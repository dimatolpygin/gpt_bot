# OpenCode Prompt — Fix "Invalid Date" в Telegram WebApp

## Контекст
GPT Telegram Bot, Telegram WebApp (src/webapp/index.html).
WebApp запустился и работает, но над сообщениями отображается **"Invalid Date"** вместо нормальной даты.
То же самое в левой панели списка диалогов.

## Симптом
- Список диалогов: "GPT Invalid Date" вместо даты последнего сообщения
- Сообщения в чате: "Invalid Date" над каждым пузырём

## Причина
В `src/webapp/index.html` (или подключаемом JS) даты форматируются примерно так:
```js
new Date(message.created_at).toLocaleString() // → "Invalid Date" если поле null/undefined/неверный формат
```

Supabase может возвращать timestamp в формате `2026-02-25T10:54:00+00:00` или `2026-02-25 10:54:00`
(без буквы T и/или без Z) — `new Date()` иногда парсит это некорректно в Safari/старых движках.

## Задача

### 1. Найди все места в src/webapp/index.html где используется форматирование дат
Поиск по: `new Date(`, `toLocaleString`, `toLocaleDateString`, `toLocaleTimeString`, `created_at`, `timestamp`

### 2. Замени ВСЕ вызовы форматирования дат на безопасную функцию

Добавь эту функцию в <script> блок:
```js
function formatDate(raw) {
  if (!raw) return '';
  // Нормализуем формат: заменяем пробел на T, добавляем Z если нет timezone
  let normalized = String(raw).trim();
  // "2026-02-25 10:54:00" → "2026-02-25T10:54:00Z"
  if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}/.test(normalized)) {
    normalized = normalized.replace(' ', 'T');
    if (!normalized.endsWith('Z') && !normalized.includes('+')) {
      normalized += 'Z';
    }
  }
  const d = new Date(normalized);
  if (isNaN(d.getTime())) return ''; // не крашим, просто пустая строка
  return d.toLocaleString('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function formatDateShort(raw) {
  if (!raw) return '';
  let normalized = String(raw).trim();
  if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}/.test(normalized)) {
    normalized = normalized.replace(' ', 'T');
    if (!normalized.endsWith('Z') && !normalized.includes('+')) normalized += 'Z';
  }
  const d = new Date(normalized);
  if (isNaN(d.getTime())) return '';
  const now = new Date();
  const isToday = d.toDateString() === now.toDateString();
  if (isToday) {
    return d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
  }
  return d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: '2-digit' });
}
```

### 3. Замени все вхождения в HTML/JS

**Для timestamp над сообщением в чате:**
```js
// БЫЛО:
const time = new Date(msg.created_at).toLocaleString();
// или
element.textContent = new Date(msg.created_at).toLocaleTimeString();

// СТАЛО:
const time = formatDate(msg.created_at);
```

**Для даты в списке диалогов (последнее сообщение):**
```js
// БЫЛО:
div.querySelector('.date').textContent = new Date(dialog.last_message_at).toLocaleString();

// СТАЛО:
div.querySelector('.date').textContent = formatDateShort(dialog.updated_at || dialog.last_message_at || dialog.created_at);
```

### 4. Проверить поле с датой в API-ответе

В `/api/history` (src/server.js) убедись что:
- Supabase возвращает поле `created_at` в каждом сообщении
- Это поле не фильтруется в select() запросе

Пример правильного запроса:
```js
const { data } = await supabase
  .from('bot_messages')
  .select('id, role, content, created_at')  // ← created_at обязательно
  .eq('conversation_id', conversationId)
  .order('created_at', { ascending: true });
```

### 5. Отладка в браузере
Открой DevTools (F12) в WebApp → Console → проверь что приходит:
```js
// Вставь временно в JS:
console.log('messages:', messages);
console.log('first msg created_at:', messages[0]?.created_at);
console.log('parsed:', new Date(messages[0]?.created_at));
```

## Ожидаемый результат
- Список диалогов: "GPT  25.02.26" или "GPT  19:54"
- Над сообщениями: "25.02.2026, 19:54"
- Если дата недоступна — пустая строка (не "Invalid Date")

## Что НЕ трогать
- Логику GPT стриминга
- HMAC-валидацию initData
- Стили чат-пузырей
- Систему диалогов и пагинацию
