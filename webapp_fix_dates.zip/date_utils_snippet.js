// ================================================
// date-utils.js — вставь в <script> в webapp/index.html
// ================================================

/**
 * Полная дата и время: "25.02.2026, 19:54"
 * Используй над сообщениями в чате
 */
function formatDate(raw) {
  if (!raw) return '';
  let s = String(raw).trim();
  // Нормализация: "2026-02-25 19:54:00" → "2026-02-25T19:54:00Z"
  if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}/.test(s)) {
    s = s.replace(' ', 'T');
    if (!s.endsWith('Z') && !/[+-]\d{2}:\d{2}$/.test(s)) s += 'Z';
  }
  const d = new Date(s);
  if (isNaN(d.getTime())) return '';
  return d.toLocaleString('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

/**
 * Короткий формат: сегодня → "19:54", другой день → "25.02.26"
 * Используй в списке диалогов
 */
function formatDateShort(raw) {
  if (!raw) return '';
  let s = String(raw).trim();
  if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}/.test(s)) {
    s = s.replace(' ', 'T');
    if (!s.endsWith('Z') && !/[+-]\d{2}:\d{2}$/.test(s)) s += 'Z';
  }
  const d = new Date(s);
  if (isNaN(d.getTime())) return '';
  const isToday = d.toDateString() === new Date().toDateString();
  return isToday
    ? d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })
    : d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: '2-digit' });
}

// ИСПОЛЬЗОВАНИЕ:
// над сообщением:   formatDate(msg.created_at)
// в списке диалогов: formatDateShort(dialog.updated_at)
